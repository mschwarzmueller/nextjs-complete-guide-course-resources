export default function Home() {
  return (
    <>
      <h1>Next.js Caching</h1>
      <p>
        Next.js performs some pretty aggressive caching. Understanding how it
        works therefore is key to avoid issues.
      </p>
    </>
  );
}
